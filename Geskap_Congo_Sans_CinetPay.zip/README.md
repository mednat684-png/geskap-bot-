# GESKAP CONGO - Version sans CinetPay

Marche à 100% au Congo-Brazza.

2 modes:
1. MANUEL (par défaut, marche tout de suite): Bot envoie tes numéros MoMo/Orange + instructions USSD, client envoie preuve, tu confirmes.
2. AUTO MTN: Si tu as compte MTN MoMo Entreprise (https://momodeveloper.mtn.com), remplis les clés et le bot lance RequestToPay auto.

Installer:
npm install
remplir .env
npm start

Webhook: /webhook
